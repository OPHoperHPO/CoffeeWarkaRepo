package ru.coffeewarka.xr10

import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.jar.Manifest


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var webview = this.findViewById<WebView>(R.id.web)
        webview.settings.setAllowFileAccessFromFileURLs(true);
        webview.settings.setAllowUniversalAccessFromFileURLs(true);
        webview.settings.setJavaScriptCanOpenWindowsAutomatically(true);
        webview.settings.setJavaScriptEnabled(true);
        webview.settings.setDomStorageEnabled(true);
        webview.settings.setJavaScriptCanOpenWindowsAutomatically(true);
        webview.settings.setBuiltInZoomControls(true);
        webview.settings.setAllowFileAccess(true);
        webview.settings.setSupportZoom(true);
        webview.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    request.grant(request.resources)
                }
            }
        }
        val permission: String = android.Manifest.permission.CAMERA
        val grant = ContextCompat.checkSelfPermission(this, permission)
        if (grant != PackageManager.PERMISSION_GRANTED) {
            val permission_list = arrayOfNulls<String>(1)
            permission_list[0] = permission
            ActivityCompat.requestPermissions(this, permission_list, 1)
        }
        webview.loadUrl("https://5kbgpro.github.io/3.html")


    }
}