package ru.coffeewarka.a10

import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import com.beust.klaxon.Json
import com.beust.klaxon.Klaxon
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalQueries.localDate
import java.util.*


class IncidentsActivity : AppCompatActivity() {
    data class IncidentsJson(
        @Json(name = "STATUS")
        val status: String,
        @Json(name = "TICKETID")
        val ticket_id: String,
        @Json(name = "REPORTEDBY")
        val reported_by: String,
        @Json(name = "CLASSIDMAIN")
        val class_id_main: String,
        @Json(name = "CRITIC_LEVEL")
        val critic_level: String,
        @Json(name = "ISKNOWNERRORDATE")
        val is_known_error_date: String,
        @Json(name = "TARGETFINISH")
        val target_finish: String,
        @Json(name = "DESCRIPTION")
        val description: String,
        @Json(name = "EXTSYSNAME")
        val ext_sys_name: String,
        @Json(name = "NORM")
        val norm: String,
        @Json(name = "LNORM")
        val lnorm: String

    )

    private fun createIncident(json_dict: IncidentsJson, IncidentsContainer:LinearLayout){
        var dubl_cont = ConstraintLayout.inflate(this, R.layout.ind_layout, null)
        dubl_cont.findViewById<TextView>(R.id.Name).text = json_dict.ext_sys_name
        dubl_cont.findViewById<TextView>(R.id.Description).text = json_dict.description

        dubl_cont.findViewById<TextView>(R.id.status).text = json_dict.status
        dubl_cont.findViewById<TextView>(R.id.Date).text =
            json_dict.is_known_error_date
        dubl_cont.findViewById<TextView>(R.id.deadlineDate).text = json_dict.target_finish

        IncidentsContainer.addView(dubl_cont)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_incidents)

        val json = CoffeeUtils().readJsonAsset("incidents.json", this)
        val json_dict = Klaxon().parseArray<IncidentsJson>( json )

        val IncidentsContainer = this.findViewById<LinearLayout>(R.id.IContainer)
        for (i in json_dict!!.iterator()){
            createIncident(i, IncidentsContainer)
        }

    }


}
