package ru.coffeewarka.a10

import android.content.Context

class CoffeeUtils {
    fun readJsonAsset(fileName: String, context: Context): String {
        val inputStream = context.assets.open(fileName)
        val size = inputStream.available()
        val buffer = ByteArray(size)
        inputStream.read(buffer)
        inputStream.close()
        return String(buffer, Charsets.UTF_8)
    }
}